package br.ufrn.jl.automacao_teste;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.UnsupportedEncodingException;

public class MainActivity extends Activity implements View.OnClickListener{

    private TextView t1;

    private Button bnt_connect;
    private MqttAndroidClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        findViewById(R.id.button_quarto).setOnClickListener(this);
        findViewById(R.id.button_sala).setOnClickListener(this);
        findViewById(R.id.button_garagem).setOnClickListener(this);
        findViewById(R.id.button_outros).setOnClickListener(this);
    }
    public void onClick(View view) {
        switch(view.getId()){

            case R.id.button_quarto:
                Intent intentQuarto = new Intent(MainActivity.this, QuartoActivity.class);
                intentQuarto.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentQuarto);
                break;

            case R.id.button_sala:
                Intent intentSala = new Intent(this, SalaActivity.class);
                intentSala.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentSala);
                break;

            case R.id.button_garagem:
                Intent intentGaragem = new Intent(this, GaragemActivity.class);
                intentGaragem.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentGaragem);
                break;

            case R.id.button_outros:
                Intent intentOutros = new Intent(this, OutrosActivity.class);
                intentOutros.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentOutros);
                break;
        }
    }
}