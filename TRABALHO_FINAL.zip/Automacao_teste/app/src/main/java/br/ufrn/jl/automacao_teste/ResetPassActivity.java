package br.ufrn.jl.automacao_teste;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class ResetPassActivity extends Activity implements View.OnClickListener {

    EditText editTextEmail;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pass);

        editTextEmail = findViewById(R.id.editTextEmail);
        progressBar=findViewById(R.id.progressbar);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        findViewById(R.id.buttonReset).setOnClickListener(this);
        findViewById(R.id.textViewBack).setOnClickListener(this);

    }

    private void passReset(){
        String mEmail = editTextEmail.getText().toString().trim();
        if(mEmail.isEmpty()){
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(mEmail).matches()){
            editTextEmail.setError("Please enter a valid email");
            editTextEmail.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        FirebaseAuth.getInstance().sendPasswordResetEmail(mEmail).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                editTextEmail.setText("");
                progressBar.setVisibility(View.GONE);
                Toast.makeText(ResetPassActivity.this, "Password reset link sent to your email. Please check your email inbox.", Toast.LENGTH_SHORT).show();
            }
            else{
                progressBar.setVisibility(View.GONE);
                Toast.makeText(ResetPassActivity.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
            }

        })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(ResetPassActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch(view.getId()){

            case R.id.buttonReset:
                passReset();
                break;

            case R.id.textViewBack:
                Intent intentLogin = new Intent(this, LoginActivity.class);
                intentLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentLogin);
                finish();
                break;
        }
    }
}
