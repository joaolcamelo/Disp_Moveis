package br.ufrn.jl.automacao_teste;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class SignUpActivity extends Activity implements View.OnClickListener{

    private GoogleSignInClient mGoogleClient;
    ProgressBar progressBar;
    EditText editTextEmail;
    TextInputEditText editTextPassword;
    private FirebaseAuth mAuth;
    private static final int RC_GOOGLE_SIGNIN = 9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword= findViewById((R.id.editTextPassword));
        progressBar = findViewById(R.id.progressbar);
        mAuth = FirebaseAuth.getInstance();

        findViewById(R.id.buttonSignUp).setOnClickListener(this);
        findViewById(R.id.textViewLogin).setOnClickListener(this);
        findViewById(R.id.sign_in_button).setOnClickListener(this);
        setupGoogleClient();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_GOOGLE_SIGNIN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            // Signed in successfully, show authenticated UI.
            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            updateUI(null);
        }
    }

    private void updateUI(GoogleSignInAccount account) {

        if (account != null){
            concluir_registro(account.getEmail(), "googleauth");
            finish();
            Intent intent = new Intent(br.ufrn.jl.automacao_teste.SignUpActivity.this, br.ufrn.jl.automacao_teste.MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
        else{
            Toast.makeText(br.ufrn.jl.automacao_teste.SignUpActivity.this,"Ocorreu algum erro na tentativa de login.",Toast.LENGTH_LONG).show();
        }

    }

    private void setupGoogleClient() {
        GoogleSignInOptions signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                //.requestIdToken(WEB_API_KEY)
                .requestEmail()
                .build();
        mGoogleClient = GoogleSignIn.getClient(this, signInOptions);
        Toast.makeText(br.ufrn.jl.automacao_teste.SignUpActivity.this,"Verifique seu email para login",Toast.LENGTH_LONG).show();

    }

    public void onGoogleButtonClick() {
        Intent intent = mGoogleClient.getSignInIntent();
        startActivityForResult(intent, RC_GOOGLE_SIGNIN);
    }

    private void registerUser(){
        String email = editTextEmail.getText().toString().trim();
        String password = Objects.requireNonNull(editTextPassword.getText()).toString().trim();
        if(email.isEmpty()){
            editTextEmail.setError("Email é necessário");
            editTextEmail.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("Por favor digite um email válido");
            editTextEmail.requestFocus();
            return;
        }

        if(password.isEmpty()){
            editTextPassword.setError("Senha é necessária");
            editTextPassword.requestFocus();
            return;
        }

        if(password.length()<6 || password.length()>15){
            editTextPassword.setError("A senha deve possuir entre 6 e 15 caracteres");
            editTextPassword.requestFocus();
            return;
        }

        concluir_registro(email, password);
    }

    private void concluir_registro(String email, String password){
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
            progressBar.setVisibility(View.GONE);
            if(task.isSuccessful()){
                if(!password.equals("googleauth")){
                    sendEmailVerification();
                }
            }
            else{
                if(task.getException() instanceof FirebaseAuthUserCollisionException){
                    editTextPassword.setText("");
                    Toast.makeText(getApplicationContext(),"Você já está registrado(a)!",Toast.LENGTH_SHORT).show();
                }
                else{
                    editTextPassword.setText("");
                    Toast.makeText(SignUpActivity.this, Objects.requireNonNull(task.getException()).getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void sendEmailVerification() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            user.sendEmailVerification().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(SignUpActivity.this,"Valide seu cadastro através do link enviado pro seu email.",Toast.LENGTH_LONG).show();
                    FirebaseAuth.getInstance().signOut();
                    editTextEmail.setText("");
                    editTextPassword.setText("");
                }
                else{
                    Toast.makeText(SignUpActivity.this, Objects.requireNonNull(task.getException()).getMessage(),Toast.LENGTH_SHORT).show();
                }

            });
        }
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch(view.getId()) {

            case R.id.buttonSignUp:
                registerUser();
                break;

            case R.id.sign_in_button:
                onGoogleButtonClick();
                break;

            case R.id.textViewLogin:
                Intent intentLogin = new Intent(this, LoginActivity.class);
                intentLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intentLogin);
                finish();

                break;
        }
    }
}
