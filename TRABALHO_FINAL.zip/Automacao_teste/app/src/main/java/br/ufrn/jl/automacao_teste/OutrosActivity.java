package br.ufrn.jl.automacao_teste;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.StandardCharsets;

public class OutrosActivity extends Activity {
    private MqttAndroidClient client;
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outros);

        ToggleButton button_cozinha_lamp = findViewById(R.id.button_cozinha_lamp);
        ToggleButton button_banheiro_lamp = findViewById(R.id.button_banheiro_lamp);

        String clientId = "xxx";

        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName("gleydvan");
        options.setPassword("PASSWORD".toCharArray());

        client =
                new MqttAndroidClient(OutrosActivity.this, "tcp://broker.hivemq.com:1883",
                        clientId);
        try {
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {

                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Toast.makeText(OutrosActivity.this, "not connected", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        findViewById(R.id.button_cozinha_lamp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(button_cozinha_lamp.isChecked()) {
                    pub("Lampada Cozinha Acesa");
                    button_cozinha_lamp.setChecked(true);
                } else {
                    pub("Lampada Cozinha Apagada");
                    button_cozinha_lamp.setChecked(false);
                }
            }
        });
        findViewById(R.id.button_banheiro_lamp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(button_banheiro_lamp.isChecked()) {
                    pub("Lampada Banheiro Acesa");
                    button_banheiro_lamp.setChecked(true);
                } else {
                    pub("Lampada Banheiro Apagada");
                    button_banheiro_lamp.setChecked(false);
                }
            }
        });
    }
    public void pub(String payload) {
        String topic = "testtopic/1";
        byte[] encodedPayload;
        try {
            encodedPayload = payload.getBytes(StandardCharsets.UTF_8);
            MqttMessage message = new MqttMessage(encodedPayload);
            client.publish(topic, message);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
